﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Name: Tom Tsiliopoulos
 * Date: July 25, 2017
 * Description: This is the Suit enum
 * Version: 0.1 - Created the Suit enum
 */

namespace COMP123_S2017_FinalExam_300930749
{
    public enum Suit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}