﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Name: Gabriel De Marchi
 * Date: July 17, 2017
 * Version: 0.1 - declared the IHasRings property
 */


namespace Abstract_Planets
{
    public interface IHasRings
    {
        bool HasRings();

    }
}