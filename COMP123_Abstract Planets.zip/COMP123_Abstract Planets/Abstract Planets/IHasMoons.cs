﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/*
 * Name: Gabriel De Marchi
 * Date: July 17, 2017  12:02am
 * Version: 0.1 - declared the IHasMoons interface
 */

namespace Abstract_Planets
{

    public interface IHasMoons
    {
        bool HasMoons();
    }
}